# Nikolukas

Contenidos: Tiene disclaimer de horarios y fechas de recogida en el footer, casi. 
Sello "producto natural"
Formulario de "contáctenos" es un google form. 
Fotos están estandarizadas (Fondo transparente, recortadas, mismo ángulo) 
Lista/Galería de productos se puede filtrar por nombre o por precio. 
Tiene breadcrumbs en la parte superior, bajo el nav
El "product card" es una tabla con las diferentes porciones y precios, abajo una descripción del producto con recomendaciones de almacenamiento, y términos y condiciones.
Diseño: Rojo, gris, blanco
Redes sociales: Facebook, Instagram
URL: https://nicolukas.com/
Ventas: Por WA, iFood, http://domicilios.com y Rappi