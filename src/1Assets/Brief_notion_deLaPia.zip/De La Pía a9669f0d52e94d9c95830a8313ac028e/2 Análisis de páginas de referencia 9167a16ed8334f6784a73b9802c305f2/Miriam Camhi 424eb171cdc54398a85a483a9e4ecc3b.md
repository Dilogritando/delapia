# Miriam Camhi

Contenidos: Divide entre categorías de productos. 
Hay buscador de productos. 
Destaca "Productos más populares"
Vende "experiencias", "productos para dos" o "empresariales"
Llamado a domicilios en la parte superior e inferior. 
El navbar superior se queda pegado cuando uno baja. 
Se puede dejar grabada la sesión y guarda carrito o lista de deseos. 
Diseño: Color azul claro - fondo blanco
Redes sociales: Facebook, Twitter, Instagram, Pinterest
URL: https://www.myriamcamhi.com/
Ventas: Por WA, se puede cotizar vía form en el site, y tiene carrito de mercado en el site