# Pastelería Toledo

Contenidos: Tiene contenido en inglés y español
También tiene WA chat
Datos de contacto arriba del nav. 
Sección "Ofertas del día"
Tiene sección "Sobre nosotros" / "Misión y visión" / "Políticas de Entrega" / "Términos y condiciones"
El Loading icon es un cupcake!
Cada "product card" se deja comparir en redes sociales. 
También venden tarjetas de regalo! 
Diseño: Rojo, blanco, negro, rosadito
Redes sociales: Facebook, Instagram, Twitter, LinkedIn
URL: http://www.latoledo.com/
Ventas: Tiene WA, carrito de compras dentro de la página,