# Rondas cambios maquetación

Date: February 2, 2021 → February 5, 2021
Fuentes: No
Logos: No
Misión / Visión / Propósito: No
Paleta de colores: No