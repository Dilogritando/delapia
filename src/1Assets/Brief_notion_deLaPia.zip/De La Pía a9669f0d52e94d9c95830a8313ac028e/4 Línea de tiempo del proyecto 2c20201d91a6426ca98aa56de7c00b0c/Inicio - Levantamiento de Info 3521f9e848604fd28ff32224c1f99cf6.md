# Inicio - Levantamiento de Info

Assign: Mariana Cortés
Date: January 25, 2021 → January 28, 2021
Fuentes: No
Logos: No
Misión / Visión / Propósito: No
Paleta de colores: No