# 3.1 Diseño (Colores y fuentes)

![3%201%20Disen%CC%83o%20(Colores%20y%20fuentes)%20a7d328ef3b1c4f66968f0827e5a12eb2/Untitled.png](3%201%20Disen%CC%83o%20(Colores%20y%20fuentes)%20a7d328ef3b1c4f66968f0827e5a12eb2/Untitled.png)

### Paleta de colores:

- #762011 —- café del texto del logo
- #B98E8C —- cafe corona 1
- #ffac33 —- piña oscuro
- #ffac4d —- piña claro
- #EF3445 —- fresa del logo
- #5864B7 —— blueberry del logo
- #5C913B —- hojas piña verde

### Fuentes:

- TÍTULOS: Aloja extended - fuente del logo, atención: la fuente "Aloja" sola no tiene minúsculas, por eso toca la extended, que se puede descargar desde: [https://fontsfree.net/aloja-extended-font-download.html](https://fontsfree.net/aloja-extended-font-download.html)
- CONTENIDO: josefin sans regular font - descargable en: [https://fonts.google.com/specimen/Josefin+Sans](https://fonts.google.com/specimen/Josefin+Sans)